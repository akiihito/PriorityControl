//
// This file is part of an OMNeT++/OMNEST simulation example.
//
// Copyright (C) 2006-2015 OpenSim Ltd.
//
// This file is distributed WITHOUT ANY WARRANTY. See the file
// `license' for details on this and other legal matters.
//

#include <iostream>
#include <fstream>
#include <vector>
#include <tuple>

#include "Source.h"
#include "Job.h"

namespace queueing {

void SourceBase::initialize()
{
    createdSignal = registerSignal("created");
    jobCounter = 0;
    WATCH(jobCounter);
    jobName = par("jobName").stringValue();
    if (jobName == "")
        jobName = getName();
}

Job *SourceBase::createJob()
{
    char buf[80];
    sprintf(buf, "%.60s-%d", jobName.c_str(), ++jobCounter);
    Job *job = new Job(buf);
    job->setKind(par("jobType"));
    job->setPriority(par("jobPriority"));
    return job;
}

void SourceBase::finish()
{
    emit(createdSignal, jobCounter);
}

//----

Define_Module(Source);

void Source::initialize()
{
    SourceBase::initialize();
    startTime = par("startTime");
    stopTime = par("stopTime");
    numJobs = par("numJobs");

    // schedule the first message timer for start time
    scheduleAt(startTime, new cMessage("newJobTimer"));
}

void Source::handleMessage(cMessage *msg)
{
    ASSERT(msg->isSelfMessage());

    if ((numJobs < 0 || numJobs > jobCounter) && (stopTime < 0 || stopTime > simTime())) {
        // reschedule the timer for the next message
        scheduleAt(simTime() + par("interArrivalTime").doubleValue(), msg);

        Job *job = createJob();
        send(job, "out");
    }
    else {
        // finished
        delete msg;
    }
}

//----

Define_Module(SourceOnce);

void SourceOnce::initialize()
{
    SourceBase::initialize();
    simtime_t time = par("time");
    scheduleAt(time, new cMessage("newJobTimer"));
}

void SourceOnce::handleMessage(cMessage *msg)
{
    ASSERT(msg->isSelfMessage());
    delete msg;

    int n = par("numJobs");
    for (int i = 0; i < n; i++) {
        Job *job = createJob();
        send(job, "out");
    }
}

Define_Module(FileBasedSource);

std::tuple<int *, int> FileBasedSource::readfile(std::string directory, std::string filename) {
    std::ifstream ifs(directory + "/" + filename);
    if (!ifs) {
        throw cRuntimeError("Could not open a file");
    } else {
        EV << "file open " << filename << std::endl;
    }

    std::vector<int> vstr;
    std::string buf;

    while (!ifs.eof()) {
        std::getline(ifs, buf);
        vstr.push_back(stoi(buf));
    }

    EV << "vector size " << vstr.size() << std::endl;
    EV << getName() << std::endl;

    int *array = new int[vstr.size()];

    for (int i=0; i<vstr.size(); i++) {
        array[i] = vstr[i];
    }

    return std::forward_as_tuple(array, vstr.size());

}


void FileBasedSource::initialize()
{
    SourceBase::initialize();
    startTime = par("startTime");
    stopTime = par("stopTime");
    numJobs = par("numJobs");
    filename = par("filename").stringValue();
    result_directory = par("result_directory").stringValue();
    locale_directory = par("locale_directory").stringValue();

    h_jobDurationSignal = registerSignal("h_duration");
    l_jobDurationSignal = registerSignal("l_duration");


    std::tie(priority_array, priority_array_size) = readfile(result_directory, filename);
    std::tie(locale_array, locale_array_size) = readfile(locale_directory, filename);
    EV << filename << std::endl;
    EV << priority_array_size << std::endl;
    EV << locale_array_size << std::endl;

    /*
    for (int i=0; i<priority_array_size; i++) {
        EV << priority_array[i] << std::endl;
    }
    for (int i=0; i<locale_array_size; i++) {
        EV << locale_array[i] << std::endl;
    }
    */

    // schedule the first message timer for start time
    scheduleAt(startTime, new cMessage("newJobTimer"));
}

Job *FileBasedSource::createJob(int priority, int destination)
{

    char buf[80];
    sprintf(buf, "%.60s-%d", jobName.c_str(), ++jobCounter);
    Job *job = new Job(buf);
    job->setKind(par("jobType"));
    job->setPriority(priority);
    job->setDestination(destination);
    job->setSource(this);
    EV << "Priority: " << priority << std::endl;
    EV << "Destination: " << destination << std::endl;
    return job;
}

void FileBasedSource::notifyCompletion(Job *job)
{
    SimTime duration;
    int priority;

    duration = job->getArrivalTime() - job->getCreationTime();
    priority = job->getPriority();

    if (priority) {
        //high priority
        emit(h_jobDurationSignal, duration);
    } else {
        //low priority
        emit(l_jobDurationSignal, duration);
    }

    EV << "Done :" << job->getFullName() << " ,duration(s): " << duration << std::endl;
}

void FileBasedSource::handleMessage(cMessage *msg)
{
    ASSERT(msg->isSelfMessage());

    int priority;
    int destination;
    int index = (int)simTime().dbl();

    if ((index - 1) < 0 || index > priority_array_size -1 ) {
        // finished
        delete msg;
    }
    else {
        priority = priority_array[index];
        destination = locale_array[index];
        // reschedule the timer for the next message
        scheduleAt(simTime() + par("interArrivalTime").doubleValue(), msg);

        Job *job = createJob(priority, destination);
        send(job, "out");
    }
}

}; //namespace
